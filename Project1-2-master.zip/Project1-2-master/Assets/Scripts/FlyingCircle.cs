﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlyingCircle : Enemy
{

    float walkingSpeed = 5;
    Vector3 currentSpeed;
    Boolean hitOnce = false;

    public override void Start()
    {
        base.Start();
        currentSpeed = new Vector3(walkingSpeed, 0);
        rb.velocity = currentSpeed;
    }

    // Update is called once per frame
    public override void FixedUpdate()
    {
        if (dead)
        {
            if (timeToDeath <= 0)
            {
                Destroy(this.gameObject);
            }
            timeToDeath -= Time.deltaTime;
        }
        else
        {
            if (rb.velocity.magnitude <= 0.1f)
            {
                currentSpeed.x *= -1;
                rb.velocity = currentSpeed;
            }
            else
            {
                rb.velocity = currentSpeed;
            }
        }
    }

    /* When a Flying Circle is hit by the player, it first enter the 
     * enraged state, increasing its speed. Then on the second hit it 
     * dies: entering the dead (squashed) animation state, settings its velocity to 0 
     * and becoming kinematic, and destroying its colliders. */
    public override void HitByPlayer(PlayerController player)
    {
        if (!hitOnce)
        {
            anim.SetTrigger("HitByPlayer");
            hitOnce = true;
            walkingSpeed += 5;
            currentSpeed = new Vector3(walkingSpeed, 0);
            rb.velocity = currentSpeed;
        } else
        {
            rb.velocity = new Vector2(0, 0);
            rb.isKinematic = true;
            dead = true;
            for (int i = myColliders.Length - 1; i >= 0; i -= 1)
            {
                Destroy(myColliders[i]);
            }
        }
    }

    /* When a Goomba hits the player, the player shrinks. See
     PlayerController.Shrink(). */
    public override void HitPlayer(PlayerController player)
    {
        player.Shrink();
    }



}

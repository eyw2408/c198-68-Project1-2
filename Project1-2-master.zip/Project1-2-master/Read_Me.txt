Our group consisted of Eric Wu, Rian Hu, Jennifer Yip.

We added a new enemy called Flying Circle. The first time Mario jumps on it, it changes color and speeds up, the second time, it dies. 
We added a new item called wings. Collecting it will allow Mario to fly like Flappy Bird.

We split the work evenly.